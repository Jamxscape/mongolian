var app = getApp()

Page({
  data: {
    movies: [
      { url: '../../images/l1.png' },
      { url: '../../images/l2.png' }
    ],
    items: [],
    slides: [],
    orderItems: [
      {
        typeId: 0,
        imageurl: '../../images/A1a.png',
        name:"翻译工具",
      },
      {
        typeId: 1,
        imageurl: '../../images/A2a.png',
        name: "真人对话",
      },
      {
        typeId: 4,
        imageurl: '../../images/A4a.png',
        name: "学习脚印",
      }
    ],
    orderItems2: [
      {
        typeId: 0,
        imageurl: '../../images/B1a.png',
      },
      {
        typeId: 1,
        imageurl: '../../images/B2b.png',
      },
    ],
    teachItems: [
      {
        teachId: 0,
        name: '趣味测验',
        imageurl: '../../images/C1a.png',
      },
      {
        teachId: 1,
        name: '趣味问答',
        imageurl: '../../images/C1b.png',
      },
      {
        teachId: 2,
        name: '常见词汇',
        imageurl: '../../images/C1c.png',
      },
    ],
    teachItems2: [
      {
        teachId: 0,
        name: '日常用语',
        imageurl: '../../images/C2a.png',
      },
      {
        teachId: 1,
        name: '教学课程',
        imageurl: '../../images/C2b.png',
      },
      {
        teachId: 2,
        name: '谚语故事',
        imageurl: '../../images/C2c.png',
      },
    ]
  },
  toOrder: function (e) {
    var that = this;
    var id = e.currentTarget.dataset.typeid;
    if (id == 0)
      wx.navigateTo({
        url: "../function/myLike/myLike"
      })
    else if (id == 1)
      wx.navigateTo({
        url: "../function/regWord/regWord"
      })
    else if (id == 2)
      wx.navigateTo({
        url: "../function/translate/translate"
      })
    else if (id == 3)
      wx.navigateTo({
        url: "../function/daily/daily"
      })
  },
  comment: function (e) {
    wx.navigateTo({
      url: "../function/comment/comment"
    })
  },
  onShareAppMessage: function () {
    return {
      title: "学习",
      desc: "首页",
      path: `pages/index/index`
    }
  },//分享页面
  nextLoad: function () {
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      duration: 4000
    })
    var next = util.getNext();
    console.log("continueload");
    var next_data = next.data;
    this.setData({
      feed: this.data.feed.concat(next_data),
      feed_length: this.data.feed_length + next_data.length
    });
    setTimeout(function () {
      wx.showToast({
        title: '加载成功',
        icon: 'success',
        duration: 2000
      })
    }, 3000)
  }


})