var app = getApp()

Page({
  data: {
    movies: [
      { url: '../../images/j1.png' },
      { url: '../../images/j2.png' }
    ],
    items: [],
    slides: [],
    orderItems: [
      {
        id: 0,
        name: '百科知识'
      },
      {
        id: 1,
        name: '做客内蒙'
      },
      {
        id: 2,
        name: '礼仪习俗'
      },
      {
        id: 3,
        name: '文化艺术'
      }
    ],
    tempitems:[
      {
        id: 0,
        name: '政治',
        imageurl: '../../images/z1.png'
      },
      {
        eid: 1,
        name: '经济',
        imageurl: '../../images/z2.png'
      },
      {
        eid: 2,
        name: '人口',
        imageurl: '../../images/z3.png'
      },
      {
        eid: 3,
        name: '历史',
        imageurl: '../../images/z4.png'
      },
      {
        eid: 4,
        name: '地理',
        imageurl: '../../images/z5.png'
      },
      {
        eid: 5,
        name: '数学',
        imageurl: '../../images/z8.png'
      },
      {
        eid: 6,
        name: '蒙医',
        imageurl: '../../images/z7.png'
      },
      {
        eid: 7,
        name: '哲学',
        imageurl: '../../images/z9.png'

      },
      {
        eid: 8,
        name: '天文历法',
        imageurl: '../../images/z6.png'
      }
    ],
    id: 0,
    eItems: [
      {
        id: 0,
        name: '政治',
        imageurl: '../../images/z1.png'
      },
      {
        eid: 1,
        name: '经济',
        imageurl: '../../images/z2.png'
      },
      {
        eid: 2,
        name: '人口',
        imageurl: '../../images/z3.png'
      },
      {
        eid: 3,
        name: '历史',
        imageurl: '../../images/z4.png'
      },
      {
        eid: 4,
        name: '地理',
        imageurl: '../../images/z5.png'
      },
      {
        eid: 5,
        name: '数学',
        imageurl: '../../images/z8.png'
      },
      {
        eid: 6,
        name: '蒙医',
        imageurl: '../../images/z7.png'
      },
      {
        eid: 7,
        name: '哲学',
        imageurl: '../../images/z9.png'

      },
      {
        eid: 8,
        name: '天文历法',
        imageurl: '../../images/z6.png'
      }
    ],
    eItems2:[//做客内蒙
      {
        eid: 0,
        name: '景点推荐',
        imageurl: '../../images/tu1.png',
      },
      {
        eid: 1,
        name: '特色特产',
        imageurl: '../../images/t2.png',
      },
      {
        eid: 2,
        name: '旅游必备',
        imageurl: '../../images/t3.png'
      }
    ],
    eItems3: [//礼仪习俗
      {
        eid: 0,
        name: '传统节日',
        imageurl: '../../images/t4.png',
      },
      {
        eid: 1,
        name: '祭祀习俗',
        imageurl: '../../images/t5.png',
      }
    ],
    eItems3_1:[
      {
        eid: 0,
        name: '生活礼仪',
        imageurl: '../../images/t6.png'
      },
      {
        eid: 1,
        name: '出行习惯',
        imageurl: '../../images/t7.png'
      }
    ],
    eItems3_2:[
      {
        eid: 0,
        name: '传统服饰',
        imageurl: '../../images/t8.png'
      },
      {
        eid: 1,
        name: '交流禁忌',
        imageurl: '../../images/t9.png'
      }
    ],
    eItems4: [//礼仪习俗
      {
        eid: 0,
        name: '文化',
        imageurl: '../../images/w1.png',
      },
      {
        eid: 1,
        name: '艺术',
        imageurl: '../../images/w2.png',
      }
    ]
  },
  superPage: function (e) {
    var that = this;
    var id = 0;
    id = e.currentTarget.dataset.id;
    var temp,temp1,temp2;
    if (id == 0) {
      temp = this.data.eItems;
    }
    else if (id == 1) {
      temp = this.data.eItems2;
    }
    else if (id == 2) {
      temp = this.data.eItems3;
    }
    else if (id == 3) {
      temp = this.data.eItems4;
    }
    this.setData({
      tempitems: temp,
      id: id
    });
  },
  onShareAppMessage: function () {
    return {
      title: "蒙果知",
      desc: "",
      path: `pages/finder/finder`
    }
  },//分享页面
  nextLoad: function () {
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      duration: 4000
    })
    var next = util.getNext();
    console.log("continueload");
    var next_data = next.data;
    this.setData({
      feed: this.data.feed.concat(next_data),
      feed_length: this.data.feed_length + next_data.length
    });
    setTimeout(function () {
      wx.showToast({
        title: '加载成功',
        icon: 'success',
        duration: 2000
      })
    }, 3000)
  }


})